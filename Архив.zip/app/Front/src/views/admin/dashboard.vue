<script setup>
    import navbar from '@/components/admin/navbar.vue'
</script>

<template>
    <navbar />

    <div class="view">
      

    </div>

    <downBar />
</template>


<style scoped>
  .view {
    margin-top: 88px;
  }
</style>