const baseURL = "http://localhost:8000";

export default baseURL;